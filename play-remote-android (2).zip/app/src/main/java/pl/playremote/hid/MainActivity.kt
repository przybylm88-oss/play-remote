package pl.playremote.hid

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var service: HidRemoteService
    private lateinit var status: TextView
    private lateinit var hosts: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        service = HidRemoteService(this)
        service.onState = { message -> runOnUiThread { status.text = message } }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 40)
        }

        status = TextView(this).apply {
            text = "Nie połączono"
            textSize = 16f
            setPadding(0, 0, 0, 12)
        }
        root.addView(status)

        root.addView(
            TextView(this).apply {
                text = "Android " + Build.VERSION.RELEASE + " · API " + Build.VERSION.SDK_INT
                textSize = 12f
                setPadding(0, 0, 0, 24)
            }
        )

        root.addView(button("Udostępnij telefon (5 min)") { makeDiscoverable() })
        root.addView(button("Odśwież listę urządzeń") { listHosts() })

        hosts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(hosts)

        root.addView(row(button("Góra") { service.send(RemoteKeys.UP) }, button("Dół") { service.send(RemoteKeys.DOWN) }))
        root.addView(
            row(
                button("Lewo") { service.send(RemoteKeys.LEFT) },
                button("OK") { service.send(RemoteKeys.OK) },
                button("Prawo") { service.send(RemoteKeys.RIGHT) }
            )
        )
        root.addView(row(button("Wstecz") { service.send(RemoteKeys.BACK) }, button("Menu") { service.send(RemoteKeys.MENU) }))
        root.addView(
            row(
                button("Rewind") { service.send(RemoteKeys.REWIND) },
                button("Play") { service.send(RemoteKeys.PLAY_PAUSE) },
                button("Forward") { service.send(RemoteKeys.FORWARD) }
            )
        )
        root.addView(
            row(
                button("Głośność -") { service.send(RemoteKeys.VOLUME_DOWN) },
                button("Wycisz") { service.send(RemoteKeys.MUTE) },
                button("Głośność +") { service.send(RemoteKeys.VOLUME_UP) }
            )
        )

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_ADVERTISE
                ),
                1
            )
        } else {
            start()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        start()
    }

    private fun start() {
        service.open()
        listHosts()
    }

    private fun makeDiscoverable() {
        val intent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
        intent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            status.text = "Nie udało się włączyć widoczności telefonu"
        }
    }

    private fun listHosts() {
        hosts.removeAllViews()
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = manager?.adapter

        if (adapter == null) {
            status.text = "Ten telefon nie ma Bluetooth"
            return
        }
        if (!adapter.isEnabled) {
            status.text = "Włącz Bluetooth w telefonie"
            return
        }

        val bonded = try {
            adapter.bondedDevices
        } catch (e: SecurityException) {
            status.text = "Brak uprawnień Bluetooth — przyznaj je w ustawieniach"
            return
        }

        if (bonded.isEmpty()) {
            status.text = "Brak sparowanych urządzeń — sparuj dekoder w ustawieniach Bluetooth"
            return
        }

        for (device in bonded) {
            val name = try {
                device.name ?: device.address
            } catch (e: SecurityException) {
                device.address
            }
            hosts.addView(button("Połącz: " + name) { service.connect(device) })
        }
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    private fun row(vararg views: Button): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            for (view in views) addView(view)
        }

    override fun onDestroy() {
        service.close()
        super.onDestroy()
    }
}