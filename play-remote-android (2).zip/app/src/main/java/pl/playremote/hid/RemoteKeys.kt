package pl.playremote.hid

sealed class RemoteCommand {
    data class Key(val usage: Int) : RemoteCommand()
    data class Media(val usage: Int) : RemoteCommand()
}

object RemoteKeys {
    val UP = RemoteCommand.Key(0x52)
    val DOWN = RemoteCommand.Key(0x51)
    val LEFT = RemoteCommand.Key(0x50)
    val RIGHT = RemoteCommand.Key(0x4F)
    val OK = RemoteCommand.Key(0x28)
    val BACK = RemoteCommand.Key(0x29)
    val MENU = RemoteCommand.Key(0x65)

    val PLAY_PAUSE = RemoteCommand.Media(0xCD)
    val REWIND = RemoteCommand.Media(0xB6)
    val FORWARD = RemoteCommand.Media(0xB5)
    val VOLUME_UP = RemoteCommand.Media(0xE9)
    val VOLUME_DOWN = RemoteCommand.Media(0xEA)
    val MUTE = RemoteCommand.Media(0xE2)
}