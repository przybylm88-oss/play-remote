package pl.playremote.hid

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Handler
import android.os.Looper

/**
 * Rejestruje telefon jako urządzenie HID i wysyła raporty do połączonego hosta.
 * Stan "Połączono" pochodzi wyłącznie z callbacku systemu, nigdy z założenia.
 */
class HidRemoteService(context: Context) {

    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())

    private val adapter: BluetoothAdapter? =
        (appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private var hidDevice: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var registered = false

    var onState: ((String) -> Unit)? = null

    private val proxyListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile != BluetoothProfile.HID_DEVICE) return
            hidDevice = proxy as BluetoothHidDevice
            register()
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hidDevice = null
                registered = false
                report("Rola HID została odebrana przez system")
            }
        }
    }

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, isRegistered: Boolean) {
            registered = isRegistered
            report(
                if (isRegistered) "Aplikacja HID zarejestrowana, wybierz dekoder"
                else "System odrzucił rejestrację aplikacji HID"
            )
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            host = if (state == BluetoothProfile.STATE_CONNECTED) device else null
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> report("Połączono z " + label(device))
                BluetoothProfile.STATE_CONNECTING -> report("Łączenie z " + label(device) + "…")
                BluetoothProfile.STATE_DISCONNECTING -> report("Rozłączanie…")
                else -> report("Rozłączono")
            }
        }
    }

    fun open() {
        val bluetooth = adapter
        if (bluetooth == null) {
            report("Ten telefon nie zgłasza adaptera Bluetooth")
            return
        }
        if (!bluetooth.isEnabled) {
            report("Włącz Bluetooth w telefonie")
            return
        }

        report("Sprawdzam, czy telefon obsługuje rolę HID…")
        val started = try {
            bluetooth.getProfileProxy(appContext, proxyListener, BluetoothProfile.HID_DEVICE)
        } catch (e: SecurityException) {
            report("Brak uprawnień Bluetooth — przyznaj je w ustawieniach")
            return
        }

        if (!started) {
            report("Ten telefon nie obsługuje roli HID Device")
            return
        }

        handler.postDelayed({
            if (hidDevice == null) report("Ten telefon nie obsługuje roli HID Device")
        }, 4000)
    }

    private fun register() {
        val hid = hidDevice ?: return
        val sdp = BluetoothHidDeviceAppSdpSettings(
            "Play Remote",
            "Pilot HID do Play BOX TV",
            "Play Remote",
            BluetoothHidDevice.SUBCLASS1_KEYBOARD,
            HidReportDescriptor.BYTES
        )
        try {
            if (!hid.registerApp(sdp, null, null, callback)) {
                report("System odrzucił rejestrację aplikacji HID")
            }
        } catch (e: SecurityException) {
            report("Brak uprawnień Bluetooth — przyznaj je w ustawieniach")
        }
    }

    fun connect(device: BluetoothDevice) {
        val hid = hidDevice ?: return report("Rola HID nie jest gotowa — spróbuj ponownie")
        if (!registered) return report("Aplikacja HID nie jest jeszcze zarejestrowana")
        try {
            if (hid.connect(device)) {
                report("Łączenie z " + label(device) + "…")
            } else {
                report("System odmówił połączenia z " + label(device))
            }
        } catch (e: SecurityException) {
            report("Brak uprawnień Bluetooth — przyznaj je w ustawieniach")
        }
    }

    fun send(command: RemoteCommand) {
        val hid = hidDevice ?: return report("Rola HID nie jest gotowa")
        val device = host ?: return report("Brak połączenia z dekoderem")

        try {
            when (command) {
                is RemoteCommand.Key -> {
                    val press = byteArrayOf(0, 0, command.usage.toByte(), 0, 0, 0, 0, 0)
                    hid.sendReport(device, HidReportDescriptor.KEYBOARD_REPORT_ID, press)
                    hid.sendReport(device, HidReportDescriptor.KEYBOARD_REPORT_ID, ByteArray(8))
                }

                is RemoteCommand.Media -> {
                    val press = byteArrayOf(
                        command.usage.toByte(),
                        (command.usage shr 8).toByte()
                    )
                    hid.sendReport(device, HidReportDescriptor.CONSUMER_REPORT_ID, press)
                    hid.sendReport(
                        device,
                        HidReportDescriptor.CONSUMER_REPORT_ID,
                        byteArrayOf(0, 0)
                    )
                }
            }
        } catch (e: SecurityException) {
            report("Brak uprawnień do wysłania polecenia")
        }
    }

    fun close() {
        handler.removeCallbacksAndMessages(null)
        val hid = hidDevice
        if (hid != null) {
            try {
                if (registered) hid.unregisterApp()
            } catch (e: SecurityException) {
                // uprawnienia odebrane — nic więcej nie zrobimy
            }
            try {
                adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid)
            } catch (e: SecurityException) {
                // jw.
            }
        }
        hidDevice = null
        host = null
        registered = false
    }

    private fun label(device: BluetoothDevice): String =
        try {
            device.name ?: device.address
        } catch (e: SecurityException) {
            device.address
        }

    private fun report(message: String) {
        handler.post { onState?.invoke(message) }
    }
}